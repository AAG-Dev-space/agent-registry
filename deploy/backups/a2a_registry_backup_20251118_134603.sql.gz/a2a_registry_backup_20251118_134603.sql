--
-- PostgreSQL database dump
--

\restrict UVIuQzklY1k2MjTERDf4ws5EMfx84UdXbfoTAiQKUdLfKUdnPedYMeApQEAzMpz

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg12+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: a2a_user
--

CREATE TABLE public.agents (
    name character varying(255) NOT NULL,
    agent_card_url character varying(512),
    agent_card jsonb NOT NULL,
    embedding public.vector(384),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.agents OWNER TO a2a_user;

--
-- Name: health_status; Type: TABLE; Schema: public; Owner: a2a_user
--

CREATE TABLE public.health_status (
    agent_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    last_check_at timestamp without time zone,
    last_response_time_ms integer,
    failure_count integer NOT NULL,
    last_error character varying(512),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.health_status OWNER TO a2a_user;

--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: a2a_user
--

COPY public.agents (name, agent_card_url, agent_card, embedding, created_at, updated_at) FROM stdin;
my-agent	\N	{"url": "http://your-domain.com", "name": "my-agent", "skills": [{"id": "skill-id", "name": "Skill Name", "tags": ["tag1", "tag2"], "description": "Skill description"}], "version": null, "metadata": null, "extensions": null, "x-registry": {"owner": "knoxid", "contact": "agent-owner@example.com", "homepage": "http://example.com/my-agent", "department": "AI Research Team", "allowDelete": true, "deleteToken": "1234", "usageDescription": "Send JSONRPC 2.0 requests to the endpoint with your desired method and parameters"}, "description": "Description of your agent", "capabilities": null, "protocol_version": null, "preferredTransport": "JSONRPC", "preferred_transport": null}	\N	2025-11-18 02:50:13.560892	2025-11-18 02:50:13.560901
test-chatbot	http://172.18.152.112:8080/.well-known/agent-card.json	{"url": "http://localhost:8080", "name": "test-chatbot", "skills": [{"id": "conversation", "name": "Basic Conversation", "tags": ["chat", "test"], "description": "Simple conversation skill"}], "version": "1.0.0", "x-registry": {"owner": "knoxid", "contact": "agent-owner@example.com", "homepage": "https://example.com/test-chatbot", "department": "AI Research Team", "allowDelete": true, "usageDescription": "Send JSONRPC 2.0 requests to the endpoint with method 'chat' and params containing 'message' field"}, "description": "A simple test chatbot for A2A registry testing", "capabilities": {"streaming": false, "pushNotifications": false, "stateTransitionHistory": false}, "protocolVersion": "0.3.0", "defaultInputModes": ["text/plain"], "defaultOutputModes": ["text/plain"], "preferredTransport": "JSONRPC"}	\N	2025-11-07 07:02:15.965538	2025-11-18 03:00:01.019309
\.


--
-- Data for Name: health_status; Type: TABLE DATA; Schema: public; Owner: a2a_user
--

COPY public.health_status (agent_name, status, last_check_at, last_response_time_ms, failure_count, last_error, created_at, updated_at) FROM stdin;
my-agent	active	2025-11-18 03:00:00.980429	970	0	\N	2025-11-18 02:50:13.563119	2025-11-18 03:00:00.980429
test-chatbot	active	2025-11-18 03:00:01.014572	13	0	\N	2025-11-07 07:02:15.96743	2025-11-18 03:00:01.014572
\.


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: a2a_user
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (name);


--
-- Name: health_status health_status_pkey; Type: CONSTRAINT; Schema: public; Owner: a2a_user
--

ALTER TABLE ONLY public.health_status
    ADD CONSTRAINT health_status_pkey PRIMARY KEY (agent_name);


--
-- Name: ix_agents_name; Type: INDEX; Schema: public; Owner: a2a_user
--

CREATE INDEX ix_agents_name ON public.agents USING btree (name);


--
-- Name: ix_health_status_agent_name; Type: INDEX; Schema: public; Owner: a2a_user
--

CREATE INDEX ix_health_status_agent_name ON public.health_status USING btree (agent_name);


--
-- PostgreSQL database dump complete
--

\unrestrict UVIuQzklY1k2MjTERDf4ws5EMfx84UdXbfoTAiQKUdLfKUdnPedYMeApQEAzMpz

